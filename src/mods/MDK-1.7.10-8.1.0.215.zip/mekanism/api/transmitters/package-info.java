@API(apiVersion = "8.0.0", owner = "Mekanism", provides = "MekanismAPI|transmitter")
package mekanism.api.transmitters;
import cpw.mods.fml.common.API;